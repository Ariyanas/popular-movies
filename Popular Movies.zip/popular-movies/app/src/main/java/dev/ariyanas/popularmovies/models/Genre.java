package dev.ariyanas.popularmovies.models;

import com.google.gson.annotations.SerializedName;

public class Genre {
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
