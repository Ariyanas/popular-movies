package dev.ariyanas.popularmovies;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import dev.ariyanas.popularmovies.lists.MovieList;
import dev.ariyanas.popularmovies.models.Movie;
import dev.ariyanas.popularmovies.services.MovieService;
import dev.ariyanas.popularmovies.utils.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    public static MovieService movieService;
    private static Context ctx;

    private static List<Movie> moviees = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ctx = getApplicationContext();

        movieService = RetrofitClient.getClient().create(MovieService.class);

        getMovieList();
    }
    
    private static void getMovieList() {
        Call<MovieList> movieRequest = movieService.getPopularMovies();
        
        movieRequest.enqueue(new Callback<MovieList>() {
            @Override
            public void onResponse(Call<MovieList> call, Response<MovieList> response) {
                MovieList movieListResponse = response.body();

                Log.d("MVIE", movieListResponse.getMovies().toString());
            }

            @Override
            public void onFailure(Call<MovieList> call, Throwable t) {
                Toast.makeText(ctx, "Failed to Fetch movies", Toast.LENGTH_SHORT).show();
                call.cancel();
            }
        });
    }

    public void openDetails(View view) {
        Intent intent = new Intent(this, MovieDetailsActivity.class);

        startActivity(intent);
    }
}
